<section class="home-sec-2">
        <div class="container">
            <div class="row">
                <div class="offset-lg-3 col-lg-7">
                    <div class="text">
                        <strong>Our Dedication</strong>
                        <h2>Why Invicta Consulting LLC?</h2>
                        <span class="line"></span>
                        <p>Invicta Consulting LLC was launched as an alternative to the consulting industry. We know the industry is flooded with bad actors offering vain promises to individuals, businesses, and financial solutions.  </p>
                        <a href="" class="t-btn white-btn">Explore More</a>
                    </div>
                </div>
            </div>
        </div>
    </section>